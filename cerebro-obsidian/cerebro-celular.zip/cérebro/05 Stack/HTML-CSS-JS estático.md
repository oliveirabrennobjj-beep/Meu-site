---
tipo: stack
tags: ["cerebro/stack"]
criado: 2026-11-02
atualizado: 2026-11-02
resumo: ""
---
# HTML-CSS-JS estático

## Como uso
<!-- Versões, configuração preferida, comandos que sempre uso. -->

## Pegadinhas
<!-- Erros que já aconteceram e como resolver. -->

## Projetos
<!-- Os projetos que usam HTML-CSS-JS estático aparecem nos backlinks desta nota. -->
