---
tipo: stack
tags: ["cerebro/stack"]
criado: 2026-11-02
atualizado: 2026-11-02
resumo: ""
---
# React

## Como uso
<!-- Versões, configuração preferida, comandos que sempre uso. -->

## Pegadinhas
<!-- Erros que já aconteceram e como resolver. -->

## Projetos
<!-- Os projetos que usam React aparecem nos backlinks desta nota. -->
