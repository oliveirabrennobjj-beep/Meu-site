---
tipo: stack
projetos: ["[[BN Digital]]", "[[BR Team]]"]
tags: ["cerebro/stack"]
criado: 2026-11-02
atualizado: 2026-11-02
resumo: "Componentes em src/components/ui com components.json, sobre React + Tailwind CSS v4."
---
# shadcn-ui

Usado em [[BN Digital]] e [[BR Team]] junto com [[React]], [[Tailwind CSS]] e [[Vite]].
