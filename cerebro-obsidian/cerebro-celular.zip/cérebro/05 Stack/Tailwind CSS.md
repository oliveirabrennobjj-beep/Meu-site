---
tipo: stack
tags: ["cerebro/stack"]
criado: 2026-11-02
atualizado: 2026-11-02
resumo: ""
---
# Tailwind CSS

## Como uso
<!-- Versões, configuração preferida, comandos que sempre uso. -->

## Pegadinhas
<!-- Erros que já aconteceram e como resolver. -->

## Projetos
<!-- Os projetos que usam Tailwind CSS aparecem nos backlinks desta nota. -->
