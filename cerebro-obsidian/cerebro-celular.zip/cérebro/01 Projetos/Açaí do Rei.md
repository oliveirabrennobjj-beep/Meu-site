---
tipo: projeto
caminho: "Meu-site/acai-do-rei"
stack: ["HTML-CSS-JS estático", "Playwright"]
projetos: ["[[Meu-site]]"]
tags: ["cerebro/projeto", "cliente"]
criado: 2026-11-02
atualizado: 2026-11-02
resumo: "Site do Açaí do Rei Delivery, na Praça do Skate em Casimiro de Abreu (RJ). Feito com a skill site-bn-digital."
---
# Açaí do Rei

## O que é
Site do Açaí do Rei Delivery, na Praça do Skate em Casimiro de Abreu (RJ). Feito com a skill site-bn-digital.
Parte do repositório [[Meu-site]] · cliente em [[Casimiro de Abreu]].

## Stack
- [[HTML-CSS-JS estático]]
- [[Playwright]]

## Padrões e decisões usados
- [[Site de cliente em HTML puro com config.js]]
- [[Fotos em WebP com srcset e lazy]]
- [[Checklist de site para comércio local]]
- [[Nunca inventar dados do cliente]]
- [[Visual elegante a partir de referência]]
- [[Publicar site novo no GitHub Pages do Meu-site]]

## Linha do tempo
