---
tipo: projeto
caminho: "Meu-site/."
stack: ["HTML-CSS-JS estático", "Playwright"]
projetos: ["[[Meu-site]]"]
tags: ["cerebro/projeto", "cliente"]
criado: 2026-11-02
atualizado: 2026-11-02
resumo: "Site da Barbearia Vértice, em Casimiro de Abreu (RJ), pensado primeiro para o celular."
---
# Barbearia Vértice

## O que é
Site da Barbearia Vértice, em Casimiro de Abreu (RJ), pensado primeiro para o celular.
Parte do repositório [[Meu-site]] · cliente em [[Casimiro de Abreu]].

## Stack
- [[HTML-CSS-JS estático]]
- [[Playwright]]

## Padrões e decisões usados
- [[Site de cliente em HTML puro com config.js]]
- [[Fotos em WebP com srcset e lazy]]
- [[Checklist de site para comércio local]]
- [[Nunca inventar dados do cliente]]
- [[Visual elegante a partir de referência]]
- [[Publicar site novo no GitHub Pages do Meu-site]]

## Linha do tempo
