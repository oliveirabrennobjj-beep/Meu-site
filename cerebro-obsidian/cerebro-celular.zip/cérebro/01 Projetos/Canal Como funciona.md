---
tipo: projeto
caminho: "Meu-site/como-funciona"
stack: ["Remotion"]
projetos: ["[[Meu-site]]"]
tags: ["cerebro/projeto", "conteudo"]
criado: 2026-11-02
atualizado: 2026-11-02
resumo: "Vídeos curtos e animados explicando como as coisas do dia a dia funcionam por dentro."
---
# Canal Como funciona

## O que é
Vídeos curtos e animados explicando como as coisas do dia a dia funcionam por dentro.
Parte do repositório [[Meu-site]].

## Stack
- [[Remotion]]

## Padrões e decisões usados
- [[Vídeo curto animado com Remotion]]

## Linha do tempo
