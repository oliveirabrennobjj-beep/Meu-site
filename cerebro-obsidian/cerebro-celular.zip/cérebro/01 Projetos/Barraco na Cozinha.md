---
tipo: projeto
caminho: "Meu-site/barraco-na-cozinha"
stack: ["Remotion"]
projetos: ["[[Meu-site]]"]
tags: ["cerebro/projeto", "conteudo"]
criado: 2026-11-02
atualizado: 2026-11-02
resumo: "Novelinha animada em capítulos, com os objetos da cozinha como personagens."
---
# Barraco na Cozinha

## O que é
Novelinha animada em capítulos, com os objetos da cozinha como personagens.
Parte do repositório [[Meu-site]].

## Stack
- [[Remotion]]

## Padrões e decisões usados
- [[Vídeo curto animado com Remotion]]

## Linha do tempo
