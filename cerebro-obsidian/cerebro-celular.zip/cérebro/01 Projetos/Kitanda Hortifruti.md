---
tipo: projeto
caminho: "Meu-site/hortifruti"
stack: ["HTML-CSS-JS estático"]
projetos: ["[[Meu-site]]"]
tags: ["cerebro/projeto", "cliente"]
criado: 2026-11-02
atualizado: 2026-11-02
resumo: "Site da Rede Kitanda Hortifruti: Casimiro de Abreu, Arraial do Cabo e Rio das Ostras (RJ)."
---
# Kitanda Hortifruti

## O que é
Site da Rede Kitanda Hortifruti: Casimiro de Abreu, Arraial do Cabo e Rio das Ostras (RJ).
Parte do repositório [[Meu-site]] · cliente em [[Casimiro de Abreu]].

## Stack
- [[HTML-CSS-JS estático]]

## Padrões e decisões usados
- [[Site de cliente em HTML puro com config.js]]
- [[Fotos em WebP com srcset e lazy]]
- [[Checklist de site para comércio local]]
- [[Nunca inventar dados do cliente]]
- [[Visual elegante a partir de referência]]
- [[Publicar site novo no GitHub Pages do Meu-site]]

## Linha do tempo
