---
tipo: projeto
caminho: "Meu-site/contos-da-madrugada"
stack: ["Remotion"]
projetos: ["[[Meu-site]]"]
tags: ["cerebro/projeto", "conteudo"]
criado: 2026-11-02
atualizado: 2026-11-02
resumo: "Perfil de histórias narradas e animadas, puxando para o mistério e o terror."
---
# Contos da Madrugada

## O que é
Perfil de histórias narradas e animadas, puxando para o mistério e o terror.
Parte do repositório [[Meu-site]].

## Stack
- [[Remotion]]

## Padrões e decisões usados
- [[Vídeo curto animado com Remotion]]

## Linha do tempo
