---
tipo: projeto
caminho: "Meu-site/raiox-das-coisas"
stack: ["HTML-CSS-JS estático"]
projetos: ["[[Meu-site]]"]
tags: ["cerebro/projeto", "conteudo"]
criado: 2026-11-02
atualizado: 2026-11-02
resumo: "Página de vendas do minicurso \"Raio-X: vídeos de curiosidade com IA\", para o link na bio."
---
# Raio-X das Coisas

## O que é
Página de vendas do minicurso "Raio-X: vídeos de curiosidade com IA", para o link na bio.
Parte do repositório [[Meu-site]].

## Stack
- [[HTML-CSS-JS estático]]

## Padrões e decisões usados
- [[Checklist de site para comércio local]]
- [[Vídeo curto animado com Remotion]]

## Linha do tempo
