---
tipo: projeto
caminho: "Meu-site/brteam"
stack: ["React", "TypeScript", "Tailwind CSS", "Vite", "shadcn-ui"]
projetos: ["[[Meu-site]]"]
tags: ["cerebro/projeto", "cliente"]
criado: 2026-11-02
atualizado: 2026-11-02
resumo: "Site da BR Team, academia de Jiu-Jitsu do professor Bruno Ramos em Casimiro de Abreu (RJ)."
---
# BR Team

## O que é
Site da BR Team, academia de Jiu-Jitsu do professor Bruno Ramos em Casimiro de Abreu (RJ).
Parte do repositório [[Meu-site]] · cliente em [[Casimiro de Abreu]].

## Stack
- [[React]]
- [[TypeScript]]
- [[Tailwind CSS]]
- [[Vite]]
- [[shadcn-ui]]

## Padrões e decisões usados
- [[Publicar site novo no GitHub Pages do Meu-site]]
- [[Checklist de site para comércio local]]
- [[Visual elegante a partir de referência]]

## Linha do tempo
