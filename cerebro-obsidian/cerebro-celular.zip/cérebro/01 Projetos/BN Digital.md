---
tipo: projeto
caminho: "Meu-site/bn-digital"
stack: ["React", "TypeScript", "Tailwind CSS", "Vite", "shadcn-ui"]
projetos: ["[[Meu-site]]"]
tags: ["cerebro/projeto", "cliente"]
criado: 2026-11-02
atualizado: 2026-11-02
resumo: "Site da agência BN Digital: sites, cardápios digitais e placas NFC para avaliações no Google."
---
# BN Digital

## O que é
Site da agência BN Digital: sites, cardápios digitais e placas NFC para avaliações no Google.
Parte do repositório [[Meu-site]] · cliente em [[Casimiro de Abreu]].

## Stack
- [[React]]
- [[TypeScript]]
- [[Tailwind CSS]]
- [[Vite]]
- [[shadcn-ui]]

## Padrões e decisões usados
- [[Publicar site novo no GitHub Pages do Meu-site]]
- [[Checklist de site para comércio local]]
- [[Visual elegante a partir de referência]]

## Linha do tempo
