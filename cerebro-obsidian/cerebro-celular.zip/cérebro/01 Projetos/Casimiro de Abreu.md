---
tipo: projeto
tags: ["cerebro/projeto", "cidade"]
criado: 2026-11-02
atualizado: 2026-11-02
resumo: "Cidade (RJ) onde ficam a maioria dos clientes da BN Digital."
---
# Casimiro de Abreu

Clientes: [[Açaí do Rei]], [[Padaria BNH]], [[Kitanda Hortifruti]], [[Barbearia Vértice]], [[BR Team]] e a própria [[BN Digital]].
