---
tipo: indice
tags: ["cerebro/indice"]
cssclasses: ["cerebro-indice"]
---
# 🗂️ Índice do cérebro

> [!info] Gerado automaticamente pelos hooks a cada entrega (última vez em 2026-11-02). Não edite este arquivo: edite as notas.
> 28 notas · 12 projeto(s) · voltar para [[Início]]

## 🟦 Projetos (12)
- [[Açaí do Rei]] — Site do Açaí do Rei Delivery, na Praça do Skate em Casimiro de Abreu (RJ). Feito com a skill site-bn-digital. · HTML-CSS-JS estático, Playwright
- [[Barbearia Vértice]] — Site da Barbearia Vértice, em Casimiro de Abreu (RJ), pensado primeiro para o celular. · HTML-CSS-JS estático, Playwright
- [[Barraco na Cozinha]] — Novelinha animada em capítulos, com os objetos da cozinha como personagens. · Remotion
- [[BN Digital]] — Site da agência BN Digital: sites, cardápios digitais e placas NFC para avaliações no Google. · React, TypeScript, Tailwind CSS, Vite, shadcn-ui
- [[BR Team]] — Site da BR Team, academia de Jiu-Jitsu do professor Bruno Ramos em Casimiro de Abreu (RJ). · React, TypeScript, Tailwind CSS, Vite, shadcn-ui
- [[Canal Como funciona]] — Vídeos curtos e animados explicando como as coisas do dia a dia funcionam por dentro. · Remotion
- [[Casimiro de Abreu]] — Cidade (RJ) onde ficam a maioria dos clientes da BN Digital.
- [[Contos da Madrugada]] — Perfil de histórias narradas e animadas, puxando para o mistério e o terror. · Remotion
- [[Kitanda Hortifruti]] — Site da Rede Kitanda Hortifruti: Casimiro de Abreu, Arraial do Cabo e Rio das Ostras (RJ). · HTML-CSS-JS estático
- [[Meu-site]] — Repositório da BN Digital: sites de clientes (um por pasta), site da agência e da BR Team, publicados no GitHub Pages. · HTML/CSS/JS estático, Vite, React, Tailwind CSS, TypeScript
- [[Padaria BNH]] — Site estático da Padaria BNH, em Casimiro de Abreu (RJ). · HTML-CSS-JS estático
- [[Raio-X das Coisas]] — Página de vendas do minicurso \"Raio-X: vídeos de curiosidade com IA\", para o link na bio. · HTML-CSS-JS estático

## 🟪 Preferências (3)
- [[Como falar com o Brenno]] — Português, respostas curtas, passo a passo, com links; mostrar resultado (capturas e link), não código. Usa muito o celular.
- [[Nunca inventar dados do cliente]] — Nunca inventar telefone, endereço, horário, preço, depoimento, número de clientes ou prêmio; o que faltar vira campo vazio e pendência. · [[Meu-site]]
- [[Visual elegante a partir de referência]] — Empresa + referência (print do Pinterest/Dribbble) = site personalizado; nível de 'shot' bonito, nunca modelo genérico. · [[Meu-site]]

## 🟩 Padrões (4)
- [[Checklist de site para comércio local]] — SEO local, acessibilidade e desempenho que todo site de cliente precisa antes de ser mostrado. · [[Meu-site]]
- [[Fotos em WebP com srcset e lazy]] — Fotos em WebP (480/960 px, até ~200 KB), srcset, width/height, lazy nas de baixo e preload só na do topo. · [[Meu-site]]
- [[Site de cliente em HTML puro com config.js]] — Sites de clientes: HTML, CSS e JS puros, sem build, com todos os dados editáveis em assets/js/config.js. · [[Meu-site]]
- [[Vídeo curto animado com Remotion]] — Vídeos curtos dos perfis feitos em código com Remotion: roteiro, projeto por vídeo e render fora do repositório. · [[Canal Como funciona]], [[Contos da Madrugada]], [[Barraco na Cozinha]]

## 🟧 Decisões (1)
- [[Publicar site novo no GitHub Pages do Meu-site]] — Sites de clientes vão para oliveirabrennobjj-beep.github.io/Meu-site/<pasta>/ via workflow publicar-bn-digital.yml, por PR. · [[Meu-site]]

## 🟨 Stack (8)
- [[HTML-CSS-JS estático]]
- [[Playwright]] — Testes de site e capturas de tela (celular 390 px e computador 1440 px), incluindo erros do console. · [[Meu-site]]
- [[React]]
- [[Remotion]]
- [[shadcn-ui]] — Componentes em src/components/ui com components.json, sobre React + Tailwind CSS v4. · [[BN Digital]], [[BR Team]]
- [[Tailwind CSS]]
- [[TypeScript]]
- [[Vite]]

## 🟥 Aprendizados (0)
_Ainda vazio._

## 🧭 Conhecimento por projeto
### [[Barraco na Cozinha]]
- 🟩 [[Vídeo curto animado com Remotion]] (Padrão)
### [[BN Digital]]
- 🟨 [[shadcn-ui]] (Stack)
### [[BR Team]]
- 🟨 [[shadcn-ui]] (Stack)
### [[Canal Como funciona]]
- 🟩 [[Vídeo curto animado com Remotion]] (Padrão)
### [[Contos da Madrugada]]
- 🟩 [[Vídeo curto animado com Remotion]] (Padrão)
### [[Meu-site]]
- 🟩 [[Checklist de site para comércio local]] (Padrão)
- 🟩 [[Fotos em WebP com srcset e lazy]] (Padrão)
- 🟩 [[Site de cliente em HTML puro com config.js]] (Padrão)
- 🟧 [[Publicar site novo no GitHub Pages do Meu-site]] (Decisão)
- 🟪 [[Nunca inventar dados do cliente]] (Preferência)
- 🟪 [[Visual elegante a partir de referência]] (Preferência)
- 🟨 [[Playwright]] (Stack)
