---
tipo: padrao
projetos: ["[[Canal Como funciona]]", "[[Contos da Madrugada]]", "[[Barraco na Cozinha]]"]
tags: ["cerebro/padrao", "video"]
criado: 2026-11-02
atualizado: 2026-11-02
resumo: "Vídeos curtos dos perfis feitos em código com Remotion: roteiro, projeto por vídeo e render fora do repositório."
---
# Vídeo curto animado com Remotion

- Uma pasta por canal com plano, roteiros e o projeto de cada vídeo.
- Feito com [[Remotion]]. Vídeos renderizados ficam no celular, não no repositório.
- Usado em [[Canal Como funciona]], [[Contos da Madrugada]] e [[Barraco na Cozinha]].
